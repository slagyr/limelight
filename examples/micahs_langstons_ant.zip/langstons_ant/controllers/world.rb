load File.expand_path(File.dirname(__FILE__) + "/ant.rb")
  
module World
  
  def self.extended(block)    
    block.cell_index = {}
    100.times do |y|
      100.times do |x|
        id = "#{x},#{y}"
        cell = Limelight::Block.new(:class_name => "cell", :id => id)
        block.add(cell)
        block.cell_index[id] = cell
      end
    end
    block.update
  end
  
  attr_accessor :cell_index
  
end
